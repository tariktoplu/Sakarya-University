﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class GunlukUretimForm : Form
    {
        private YemekCesitDepo ycDepo = new YemekCesitDepo();
        private Depo depo = new Depo();
        private List<GunlukYemek> gy;
        private List<MalzemeSiparis> ms;
        RefBoolean gunlukHazirlama;
        public GunlukUretimForm(List<GunlukYemek> gy, List<MalzemeSiparis> ms, RefBoolean gunlukHazirlama)
        {
            InitializeComponent();
            this.gy = gy;
            this.ms = ms;
            this.gunlukHazirlama = gunlukHazirlama;
            yemekCombo.DataSource = ycDepo.Rapor();
            yemekCombo.DisplayMember = "YiyecekAdi";
            adetCombo.SelectedIndex = 0;
            gungelleYemekGridBox();
            if (gunlukHazirlama.Value)
            {
                yemekListBox.SelectedIndex = -1;
                ekleBtn.Enabled = false;
                silBtn.Enabled = false;
                kaydetBtn.Enabled = false;
                adetCombo.Enabled = false;
                yemekCombo.Enabled = false;
                yemekListBox.Enabled = false;
            }
        }

        private void RaporGuncelleme()
        {
            raporTextBox.Text = "Uretilecek Yiyecekler:\n----------\n";
            double toplam = 0;
            foreach (GunlukYemek g in gy)
            {
                string isim = g.yc.YiyecekAdi;
                int adet = g.Adet;
                double fiyat = g.yc.yiyecek.Fiyat;
                double toplamFiyat = fiyat * adet;
                toplam += toplamFiyat;
                raporTextBox.Text += $"{isim} X {adet} = {fiyat} X {adet} = {toplamFiyat} TL\n";
            }
            raporTextBox.Text += $"----------------\n";
            raporTextBox.Text += $"Toplam Tutari: {toplam} TL\n";
        }

        private void gungelleYemekGridBox()
        {
            yemekListBox.DataSource = null;
            yemekListBox.DataSource = gy;
            yemekListBox.DisplayMember = "Goster";
            if (yemekListBox.Items.Count > 0)
            {
                silBtn.Enabled = true;
            }
            else
            {
                silBtn.Enabled = false;
            }
            RaporGuncelleme();
        }

        private void ekleBtn_Click(object sender, EventArgs e)
        {
            YemekCesit yc =  (YemekCesit) yemekCombo.SelectedItem;
            int adet = Convert.ToInt32((string)adetCombo.SelectedItem);

            bool mevcut = false;
            foreach(GunlukYemek g in gy)
            {
                if (g.yc.YiyecekAdi == yc.YiyecekAdi)
                {
                    mevcut = true;
                    break;
                }
            }
            
            if (!mevcut)
            {
                gy.Add(new GunlukYemek(yc, adet));
            }
            gungelleYemekGridBox();
        }

        private void silBtn_Click(object sender, EventArgs e)
        {
            if (yemekListBox.Items.Count > 0)
            {
                GunlukYemek g = (GunlukYemek) yemekListBox.SelectedItem;
                gy.Remove(g);
                gungelleYemekGridBox();
            }
        }

        private void kaydetBtn_Click(object sender, EventArgs e)
        {
            foreach(GunlukYemek g in gy)
            {
                foreach(KeyValuePair<Urun, int> kvp in g.yc.malzeme)
                {
                    Urun depodanUrun = depo.GetUrun(kvp.Key.Adi);
                    if (depodanUrun == null)
                    {
                        MalzemeSiparis mlzmSprs = new MalzemeSiparis(kvp.Key, kvp.Value * g.Adet);
                        ms.Add(mlzmSprs);
                    } else
                    {
                        int mevcutAdet = depodanUrun.StokAdet;
                        int aldiktanSonraAdet = mevcutAdet - kvp.Value * g.Adet;
                        if (aldiktanSonraAdet >= 0)
                        {
                            depodanUrun.StokAdet = aldiktanSonraAdet;
                            depo.Guncelle(depodanUrun.Adi, depodanUrun);
                        } else
                        {
                            depodanUrun.StokAdet = 0;
                            depo.Guncelle(depodanUrun.Adi, depodanUrun);
                            MalzemeSiparis mlzmSprs = new MalzemeSiparis(kvp.Key, aldiktanSonraAdet * -1);
                            ms.Add(mlzmSprs);
                        }
                    }
                }
            }

            string rapor = "Satilacak Malzemeler:\n-------------\n";
            double toplam = 0;
            foreach (MalzemeSiparis m in ms)
            {
                rapor += $"{m.urun.Adi} X {m.Adet} = {m.urun.Fiyat} X {m.Adet} = {m.urun.Fiyat * m.Adet} TL\n";
                toplam += m.urun.Fiyat * m.Adet;
            }
            rapor += "----------\n";
            rapor += $"Toplam Tutar: {toplam} TL";
            raporTextBox.Text += $"\n\n\n{rapor}";
            raporTextBox.Text += $"\n\n\n Gunluk Menu Hazirlandi.";
            gunlukHazirlama.Value = true;
            yemekListBox.SelectedIndex = -1;
            ekleBtn.Enabled = false;
            silBtn.Enabled = false;
            kaydetBtn.Enabled = false;
            adetCombo.Enabled = false;
            yemekCombo.Enabled = false;
            yemekListBox.Enabled = false;
        }
    }
    
}
