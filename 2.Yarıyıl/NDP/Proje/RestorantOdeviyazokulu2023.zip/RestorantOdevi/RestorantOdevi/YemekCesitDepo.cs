﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public class YemekCesitDepo
    {
        private string yemekDosya = "yemekcesit.txt";
        private string malzemeDosya = "malzeme.txt";

        public void Ekle(YemekCesit yc)
        {
            bool mevcut = false;
            StreamReader ysr = new StreamReader(yemekDosya);
            StreamReader msr = new StreamReader(malzemeDosya);
            string ySatir = ysr.ReadLine();
            string mSatir = msr.ReadLine();
            while (ySatir != null)
            {
                YemekCesit ymkCstDepo = new YemekCesit(ySatir, mSatir);
                if (ymkCstDepo.yiyecek.Adi == yc.yiyecek.Adi)
                {
                    mevcut = true;
                    break;
                }
                ySatir = ysr.ReadLine();
                mSatir = msr.ReadLine();
            }
            ysr.Close();
            msr.Close();

            StreamWriter ysw = new StreamWriter(yemekDosya, true);
            StreamWriter msw = new StreamWriter(malzemeDosya, true);
            if (!mevcut)
            {
                ysw.WriteLine(yc.yiyecekSatir());
                msw.WriteLine(yc.malzemeSatir());
            }
            ysw.Close();
            msw.Close();
        }

        public void Sil(YemekCesit yc)
        {
            List<string> yemekler = new List<string>();
            List<string> malzemeler = new List<string>();
            StreamReader ysr = new StreamReader(yemekDosya);
            StreamReader msr = new StreamReader(malzemeDosya);
            string ySatir = ysr.ReadLine();
            string mSatir = msr.ReadLine();
            while (ySatir != null)
            {
                YemekCesit ymkCstDepo = new YemekCesit(ySatir, mSatir);
                if (ymkCstDepo.yiyecek.Adi != yc.yiyecek.Adi)
                {
                    yemekler.Add(ySatir);
                    malzemeler.Add(mSatir);
                }
                ySatir = ysr.ReadLine();
                mSatir = msr.ReadLine();
            }
            ysr.Close();
            msr.Close();

            StreamWriter ysw = new StreamWriter(yemekDosya, false);
            StreamWriter msw = new StreamWriter(malzemeDosya, false);
            foreach (string str in yemekler) {
                ysw.WriteLine(str);
            }
            foreach (string str in malzemeler)
            {
                msw.WriteLine(str);
            }
            ysw.Close();
            msw.Close();
        }

        public void Guncelle(string ad, YemekCesit yc)
        {
            List<string> yemekler = new List<string>();
            List<string> malzemeler = new List<string>();
            StreamReader ysr = new StreamReader(yemekDosya);
            StreamReader msr = new StreamReader(malzemeDosya);
            string ySatir = ysr.ReadLine();
            string mSatir = msr.ReadLine();
            while (ySatir != null)
            {
                YemekCesit ymkCstDepo = new YemekCesit(ySatir, mSatir);
                if (ymkCstDepo.yiyecek.Adi != ad)
                {
                    yemekler.Add(ySatir);
                    malzemeler.Add(mSatir);
                }
                else
                {
                    yemekler.Add(yc.yiyecekSatir());
                    malzemeler.Add(yc.malzemeSatir());
                }
                ySatir = ysr.ReadLine();
                mSatir = msr.ReadLine();
            }
            ysr.Close();
            msr.Close();

            StreamWriter ysw = new StreamWriter(yemekDosya, false);
            StreamWriter msw = new StreamWriter(malzemeDosya, false);
            foreach (string str in yemekler)
            {
                ysw.WriteLine(str);
            }
            foreach (string str in malzemeler)
            {
                msw.WriteLine(str);
            }
            ysw.Close();
            msw.Close();
        }

        public List<YemekCesit> Rapor()
        {
            List<YemekCesit> yemekler = new List<YemekCesit>();
            StreamReader ysr = new StreamReader(yemekDosya);
            StreamReader msr = new StreamReader(malzemeDosya);
            string ySatir = ysr.ReadLine();
            string mSatir = msr.ReadLine();
            while (ySatir != null)
            {
                yemekler.Add(new YemekCesit(ySatir, mSatir));
                ySatir = ysr.ReadLine();
                mSatir = msr.ReadLine();
            }
            ysr.Close();
            msr.Close();
            return yemekler;
        }

        public void Temizle()
        {
            StreamWriter ysw = new StreamWriter(yemekDosya, false);
            StreamWriter msw = new StreamWriter(malzemeDosya, false);
            
            ysw.Close();
            msw.Close();
        }
    }
}
