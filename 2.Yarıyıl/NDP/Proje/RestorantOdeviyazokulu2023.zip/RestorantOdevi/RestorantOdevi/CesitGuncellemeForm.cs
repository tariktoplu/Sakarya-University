﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class CesitGuncellemeForm : Form
    {
        private Yiyecek yiyecek;
        public CesitGuncellemeForm(Yiyecek y)
        {
            InitializeComponent();
            this.yiyecek = y;
            cesitAdText.Text = y.Adi;
            cesitCinsText.Text = y.Cins;
            cesitFiyatText.Text = y.Fiyat.ToString();
            cesitKdvText.Text = y.KdvOrani.ToString();
        }

        private void guncelleBtn_Click(object sender, EventArgs e)
        {
            yiyecek.Adi = cesitAdText.Text;
            yiyecek.Cins = cesitCinsText.Text;
            yiyecek.Fiyat = Convert.ToDouble(cesitFiyatText.Text);
            yiyecek.KdvOrani = Convert.ToDouble(cesitKdvText.Text);
            this.Close();
        }
    }
}
