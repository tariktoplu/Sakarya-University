﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    public class MalzemeSiparis
    {
        public Urun urun { get; set; }
        public int Adet { get; set; }

        public MalzemeSiparis(Urun urun, int adet)
        {
            this.urun = urun;
            Adet = adet;
        }
    }
}
