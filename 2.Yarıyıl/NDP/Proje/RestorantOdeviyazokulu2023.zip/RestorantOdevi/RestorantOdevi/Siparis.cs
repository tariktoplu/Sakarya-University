﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    public class Siparis
    {
        public List<Yiyecek> liste;
        public Siparis() { 
            liste = new List<Yiyecek>();
        }
        public void Ekle(Yiyecek y)
        {
            liste.Add(y);
        }

        public void Sil(Yiyecek y)
        {
            liste.Remove(y);
        }

        public List<Yiyecek> Yazdir()
        {
            return liste;
        }
    }
}
