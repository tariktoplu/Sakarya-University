﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class RaporForm : Form
    {
        public List<GunlukYemek> gy;
        public List<MalzemeSiparis> ms;
        public Siparis siparis;

        double uretim;
        double satis;

        public RaporForm(List<GunlukYemek> gy, List<MalzemeSiparis> ms, Siparis siparis)
        {
            InitializeComponent();
            this.gy = gy;
            this.ms = ms;
            this.siparis = siparis;

            UretimMakliyeti();
            SatisRaporu();
            KalanYemekler();
            Ozet();
        }

        public void Ozet()
        {
            ozetBox.Text += $"Toplam Maliyet = {uretim} TL\n";
            ozetBox.Text += $"Toplam Satis = {satis} TL\n";
            double fark = satis - uretim;
            string sonuc = "";
            if (fark >= 0) sonuc = "Kar";
            else if (fark < 0) sonuc = "Zarar";
            ozetBox.Text += $"Sonuc = {fark} TL {sonuc}\n";
        }

        public void KalanYemekler()
        {
            string rapor = "";

            foreach (GunlukYemek g in gy)
            {
                string ad = g.yc.yiyecek.Adi;
                int kalan = g.Adet - g.satilan;
                string satir = $"{ad}: {kalan} Kaldi\n";
                rapor += satir;
            }
            kyBox.Text = rapor;
        }

        public void SatisRaporu()
        {
            string rapor = "";
            double toplam = 0;
            Dictionary<string, int> adetler = new Dictionary<string, int>();
            Dictionary<string, double> fiyatlar = new Dictionary<string, double>();

            foreach (Yiyecek y in siparis.liste)
            {
                string ad = y.Adi;
                double fiyat = y.Fiyat;

                if (adetler.ContainsKey(ad))
                {
                    adetler[ad] += 1;
                }
                else
                {
                    adetler[ad] = 1;
                    fiyatlar[ad] = fiyat;
                }
            }

            foreach (KeyValuePair<string, int> kvp in adetler)
            {
                string ad = kvp.Key;
                int adet = kvp.Value;
                double fiyat = fiyatlar[ad];
                double toplamFiyat = fiyat * adet;
                toplam += toplamFiyat;
                string satir = $"{ad}: {adet} adet X {fiyat} TL = {toplamFiyat} TL\n";
                rapor += satir;
            }

            rapor += "---------\n";
            rapor += $"Toplam: {toplam} Tl";
            srBox.Text = rapor;
            this.satis = toplam;
        }

        public void UretimMakliyeti()
        {
            string rapor = "";
            double toplam = 0;
            Dictionary<string, int> adetler = new Dictionary<string, int>();
            Dictionary<string, double> fiyatlar = new Dictionary<string, double>();

            foreach (GunlukYemek g in gy)
            {
                foreach(KeyValuePair<Urun, int> kvp in g.yc.malzeme)
                {
                    string ad = kvp.Key.Adi;
                    double fiyat = kvp.Key.Fiyat;
                    int adet = g.Adet * kvp.Value;


                    if (adetler.ContainsKey(ad))
                    {
                        adetler[ad] += adet;
                    } else
                    {
                        adetler[ad] = adet;
                        fiyatlar[ad] = fiyat;
                    }
                }
            }

            foreach (KeyValuePair<string, int> kvp in adetler)
            {
                string ad = kvp.Key;
                int adet = kvp.Value;
                double fiyat = fiyatlar[ad];
                double toplamFiyat = fiyat * adet;
                toplam += toplamFiyat;
                string satir = $"{ad}: {adet} adet X {fiyat} TL = {toplamFiyat} TL\n";
                rapor += satir;
            }

            rapor += "---------\n";
            rapor += $"Toplam: {toplam} Tl";
            umBox.Text = rapor;
            this.uretim = toplam;
        }
    }
}
