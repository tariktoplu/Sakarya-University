﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class YemekCesitForm : Form
    {

        YemekCesitDepo ycDepo = new YemekCesitDepo();
        List<YemekCesit> yc;

        public YemekCesitForm()
        {
            InitializeComponent();
            yc = ycDepo.Rapor();
            cesitListBox.DataSource = yc;
            cesitListBox.DisplayMember = "YiyecekAdi";
            urunlerCombo.DataSource = new Depo().Rapor();
            urunlerCombo.DisplayMember = "Adi";
            GuncelleCesitList();
        }

        private void GuncelleCesitList()
        {
            cesitListBox.DataSource = null;
            cesitListBox.DataSource = yc;
            cesitListBox.DisplayMember = "YiyecekAdi";
            if (cesitListBox.Items.Count > 0)
            {
                silCesitBtn.Enabled = true;
                guncelleCesitBtn.Enabled = true;
                malzemelerEnabled(true);
            }
            else
            {
                silCesitBtn.Enabled = false;
                guncelleCesitBtn.Enabled = false;
                malzemelerEnabled(false);
            }
        }

        private void malzemelerEnabled(bool durum)
        {
            malzemeListBox.Enabled = durum;
            malzemeEkle.Enabled = durum;
            malzemeSil.Enabled = durum;
            malzemeAdetText.Enabled = durum;
            urunlerCombo.Enabled = durum;
        }

        private void DosyadanGuncelle()
        {
            yc = ycDepo.Rapor();
            GuncelleCesitList();
        }

        private void ekleCesitBtn_Click(object sender, EventArgs e)
        {
            string yAdi = cesitAdText.Text;
            string yCins = cesitCinsText.Text;
            double yFiyat = Convert.ToDouble(cesitFiyatText.Text);
            double yKdv = Convert.ToDouble(cesitKdvText.Text);
            
            Yiyecek y = new Yiyecek(yAdi, yCins, yFiyat, yKdv);
            YemekCesit yeniCesit = new YemekCesit(y, new Dictionary<Urun, int>());
            yc.Add(yeniCesit);
            GuncelleCesitList();
        }

        private void cesitListBox_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cesitListBox.SelectedItems.Count > 0)
            {
                YemekCesit secilenYemekCesit = (YemekCesit) cesitListBox.SelectedItems[0];
                List<string> malzemeler = new List<string>();
                foreach (KeyValuePair<Urun, int> kvp in secilenYemekCesit.malzeme)
                {
                    malzemeler.Add($"{kvp.Key.Adi} -- {kvp.Value}");
                }
                malzemeListBox.DataSource = null;
                malzemeListBox.DataSource = malzemeler;
            }
        }

        private void silCesitBtn_Click(object sender, EventArgs e)
        {
            if (cesitListBox.SelectedItems.Count > 0)
            {
                YemekCesit secilenYemekCesit = (YemekCesit)cesitListBox.SelectedItems[0];
                yc.Remove(secilenYemekCesit);
                GuncelleCesitList();
            }
        }

        private void malzemeSil_Click(object sender, EventArgs e)
        {
            if (cesitListBox.SelectedItems.Count > 0)
            {
                YemekCesit secilenYemekCesit = (YemekCesit)cesitListBox.SelectedItems[0];
                if (malzemeListBox.SelectedItems.Count > 0)
                {
                    int secilenMalzemeIndisi = malzemeListBox.SelectedIndex;
                    secilenYemekCesit.malzeme.Remove(secilenYemekCesit.malzeme.Keys.ToList()[secilenMalzemeIndisi]);
                }
                List<string> malzemeler = new List<string>();
                foreach (KeyValuePair<Urun, int> kvp in secilenYemekCesit.malzeme)
                {
                    malzemeler.Add($"{kvp.Key.Adi} -- {kvp.Value}");
                }
                malzemeListBox.DataSource = null;
                malzemeListBox.DataSource = malzemeler;
            }
        }

        private void malzemeEkle_Click(object sender, EventArgs e)
        {
            if (cesitListBox.SelectedItems.Count > 0)
            {
                YemekCesit secilenYemekCesit = (YemekCesit)cesitListBox.SelectedItems[0];

                Urun secilerUrun = (Urun)urunlerCombo.SelectedItem;
                int adet = Convert.ToInt32(malzemeAdetText.Text);

                bool urunMevcut = false;
                foreach (KeyValuePair<Urun, int> kvp in secilenYemekCesit.malzeme)
                {
                    if (kvp.Key.Adi == secilerUrun.Adi)
                    {
                        urunMevcut = true;
                    }
                }
                if (!urunMevcut)
                {
                    secilenYemekCesit.malzeme.Add(secilerUrun, adet);
                }

                List<string> malzemeler = new List<string>();
                foreach (KeyValuePair<Urun, int> kvp in secilenYemekCesit.malzeme)
                {
                    malzemeler.Add($"{kvp.Key.Adi} -- {kvp.Value}");
                }
                malzemeListBox.DataSource = null;
                malzemeListBox.DataSource = malzemeler;
            }
        }

        private void guncelleCesitBtn_Click(object sender, EventArgs e)
        {
            if (cesitListBox.SelectedItems.Count > 0)
            {
                YemekCesit secilenYemekCesit = (YemekCesit)cesitListBox.SelectedItems[0];
                new CesitGuncellemeForm(secilenYemekCesit.yiyecek).ShowDialog();
                GuncelleCesitList();
            }
        }

        private void kaydetBtn_Click(object sender, EventArgs e)
        {
            ycDepo.Temizle();
            foreach(YemekCesit y in yc)
            {
                ycDepo.Ekle(y);
            }
            DosyadanGuncelle();
        }
    }
}
