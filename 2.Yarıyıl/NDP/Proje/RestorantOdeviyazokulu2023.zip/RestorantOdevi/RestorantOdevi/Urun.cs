﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    public class Urun
    {
        private string urunAdi;
        private int stokAdet;
        private double fiyat;
        private int uretimTarihi;
        private int sonKullanmaTarihi;

        public string Adi { get { return this.urunAdi; } }
        public int StokAdet { get { return this.stokAdet; } set { this.stokAdet = value; } }
        public double Fiyat { get { return this.fiyat; } }
        public int UretimTarihi { get { return this.uretimTarihi; } }
        public int SonKullanmaTarihi { get { return this.sonKullanmaTarihi; } }

        public Urun(string urunAdi, int stokAdet, double fiyat, int ut, int skt)
        {
            this.urunAdi = urunAdi;
            this.stokAdet = stokAdet;
            this.fiyat = fiyat;
            this.uretimTarihi = ut;
            this.sonKullanmaTarihi = skt;
        }

        public Urun(string depoStr)
        {
            string[] arr = depoStr.Split(';');
            this.urunAdi = arr[0];
            this.stokAdet = Convert.ToInt32(arr[1]);
            this.fiyat = Convert.ToDouble(arr[2]);
            this.uretimTarihi = Convert.ToInt32(arr[3]);
            this.sonKullanmaTarihi = Convert.ToInt32(arr[4]);
        }

        public string DepoSatir()
        {
            return $"{urunAdi};{stokAdet};{fiyat};{uretimTarihi};{sonKullanmaTarihi}";
        }
    }
}
