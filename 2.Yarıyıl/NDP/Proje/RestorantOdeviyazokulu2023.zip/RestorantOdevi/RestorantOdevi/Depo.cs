﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public class Depo
    {
        private string dosya = "Depo.txt";

        public void Ekle(Urun u)
        {
            bool mevcut = false;
            StreamReader sr = new StreamReader(dosya);
            string satir = sr.ReadLine();
            while (satir != null)
            {
                Urun depoUrun = new Urun(satir);
                if (depoUrun.Adi == u.Adi)
                {
                    mevcut = true;
                    break;
                }
                satir = sr.ReadLine();
            }
            sr.Close();

            StreamWriter sw = new StreamWriter(dosya, true);
            if (!mevcut)
            {
                sw.WriteLine(u.DepoSatir());
            }
            sw.Close();
        }

        public void Sil(Urun u)
        {
            List<string> urunler = new List<string>();
            StreamReader sr = new StreamReader(dosya);
            string satir = sr.ReadLine();
            while (satir != null)
            {
                Urun depoUrun = new Urun(satir);
                if (depoUrun.Adi != u.Adi)
                {
                    urunler.Add(satir);
                }
                satir = sr.ReadLine();
            }
            sr.Close();

            StreamWriter sw = new StreamWriter(dosya, false);
            foreach (string str in urunler) {
                sw.WriteLine(str);
            }
            sw.Close();
        }

        public void Guncelle(string ad, Urun u)
        {
            List<string> urunler = new List<string>();
            StreamReader sr = new StreamReader(dosya);
            string satir = sr.ReadLine();
            while (satir != null)
            {
                Urun depoUrun = new Urun(satir);
                if (depoUrun.Adi != ad)
                {
                    urunler.Add(satir);
                }
                else
                {
                    urunler.Add(u.DepoSatir());
                }
                satir = sr.ReadLine();
            }
            sr.Close();

            StreamWriter sw = new StreamWriter(dosya, false);
            foreach (string str in urunler)
            {
                sw.WriteLine(str);
            }
            sw.Close();
        }

        public List<Urun> Rapor()
        {
            List<Urun> urunler = new List<Urun>();
            StreamReader sr = new StreamReader(dosya);
            string satir = sr.ReadLine();
            while (satir != null)
            {
                urunler.Add(new Urun(satir));
                satir = sr.ReadLine();
            }
            sr.Close();
            return urunler;
        }

        public Urun GetUrun(string ad)
        {
            StreamReader sr = new StreamReader(dosya);
            string satir = sr.ReadLine();
            while (satir != null)
            {
                Urun u = new Urun(satir);
                if (u.Adi == ad)
                {
                    sr.Close();
                    return u;
                }
                satir = sr.ReadLine();
            }
            sr.Close();
            return null;
        }
    }
}
