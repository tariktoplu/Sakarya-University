﻿namespace RestorantOdevi
{
    partial class CesitGuncellemeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.cesitKdvText = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cesitFiyatText = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cesitCinsText = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cesitAdText = new System.Windows.Forms.TextBox();
            this.guncelleBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 118);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 20);
            this.label11.TabIndex = 38;
            this.label11.Text = "KDV Orani:";
            // 
            // cesitKdvText
            // 
            this.cesitKdvText.Location = new System.Drawing.Point(109, 118);
            this.cesitKdvText.Name = "cesitKdvText";
            this.cesitKdvText.ShortcutsEnabled = false;
            this.cesitKdvText.Size = new System.Drawing.Size(131, 20);
            this.cesitKdvText.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(56, 142);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 20);
            this.label10.TabIndex = 36;
            this.label10.Text = "Fiyat:";
            // 
            // cesitFiyatText
            // 
            this.cesitFiyatText.Location = new System.Drawing.Point(109, 142);
            this.cesitFiyatText.Name = "cesitFiyatText";
            this.cesitFiyatText.ShortcutsEnabled = false;
            this.cesitFiyatText.Size = new System.Drawing.Size(131, 20);
            this.cesitFiyatText.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(59, 92);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 20);
            this.label9.TabIndex = 34;
            this.label9.Text = "Cins:";
            // 
            // cesitCinsText
            // 
            this.cesitCinsText.Location = new System.Drawing.Point(109, 92);
            this.cesitCinsText.Name = "cesitCinsText";
            this.cesitCinsText.ShortcutsEnabled = false;
            this.cesitCinsText.Size = new System.Drawing.Size(131, 20);
            this.cesitCinsText.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 20);
            this.label4.TabIndex = 30;
            this.label4.Text = "isim:";
            // 
            // cesitAdText
            // 
            this.cesitAdText.Location = new System.Drawing.Point(109, 66);
            this.cesitAdText.Name = "cesitAdText";
            this.cesitAdText.ShortcutsEnabled = false;
            this.cesitAdText.Size = new System.Drawing.Size(131, 20);
            this.cesitAdText.TabIndex = 31;
            // 
            // guncelleBtn
            // 
            this.guncelleBtn.Location = new System.Drawing.Point(109, 184);
            this.guncelleBtn.Name = "guncelleBtn";
            this.guncelleBtn.Size = new System.Drawing.Size(131, 23);
            this.guncelleBtn.TabIndex = 33;
            this.guncelleBtn.Text = "Guncelle";
            this.guncelleBtn.UseVisualStyleBackColor = true;
            this.guncelleBtn.Click += new System.EventHandler(this.guncelleBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 24);
            this.label1.TabIndex = 29;
            this.label1.Text = "CESIT GUNCELLE";
            // 
            // CesitGuncellemeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 228);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cesitKdvText);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cesitFiyatText);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cesitCinsText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cesitAdText);
            this.Controls.Add(this.guncelleBtn);
            this.Controls.Add(this.label1);
            this.Name = "CesitGuncellemeForm";
            this.Text = "Cesit Guncelleme";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox cesitKdvText;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox cesitFiyatText;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox cesitCinsText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox cesitAdText;
        private System.Windows.Forms.Button guncelleBtn;
        private System.Windows.Forms.Label label1;
    }
}