﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class SiparisVerForm : Form
    {
        List<GunlukYemek> gy;
        Siparis siparis;
        public SiparisVerForm(List<GunlukYemek> gy, Siparis s)
        {
            InitializeComponent();
            this.gy = gy;
            this.siparis = s;
            yemekCombo.DataSource = gy;
            yemekCombo.DisplayMember = "kisilikKalanGoster";
            yemekListBox.DataSource = null;
            yemekListBox.DataSource = siparis.liste;
            yemekListBox.DisplayMember = "Adi";
        }

        private void ekleBtn_Click(object sender, EventArgs e)
        {
            if (((GunlukYemek)yemekCombo.SelectedItem).satilan == ((GunlukYemek)yemekCombo.SelectedItem).Adet)
            {
                return;
            }

            Yiyecek y = ((GunlukYemek)yemekCombo.SelectedItem).yc.yiyecek;
            ((GunlukYemek)yemekCombo.SelectedItem).satilan++;

            yemekCombo.DataSource = null;
            yemekCombo.DataSource = gy;
            yemekCombo.DisplayMember = "kisilikKalanGoster";
            siparis.Ekle(y);
            yemekListBox.DataSource = null;
            yemekListBox.DataSource = siparis.liste;
            yemekListBox.DisplayMember = "Adi";
        }

        private void silBtn_Click(object sender, EventArgs e)
        {
            if (yemekListBox.SelectedItems.Count > 0)
            {
                Yiyecek y = (Yiyecek) yemekListBox.SelectedItem;
                foreach(GunlukYemek g in gy)
                {
                    if (g.yc.yiyecek.Adi == y.Adi)
                    {
                        g.satilan--;
                    }
                }
                
                yemekCombo.DataSource = null;
                yemekCombo.DataSource = gy;
                yemekCombo.DisplayMember = "kisilikKalanGoster";
                siparis.Sil(y);
                yemekListBox.DataSource = null;
                yemekListBox.DataSource = siparis.liste;
                yemekListBox.DisplayMember = "Adi";
            }
        }
    }
}
