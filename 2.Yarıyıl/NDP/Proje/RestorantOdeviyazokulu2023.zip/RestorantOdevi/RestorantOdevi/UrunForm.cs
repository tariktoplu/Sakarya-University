﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class UrunForm : Form
    {

        Depo depo;
        List<Urun> urunler;
        public UrunForm()
        {
            InitializeComponent();
            depo = new Depo();
            urunler = depo.Rapor();
            updateUrunlerInDataGrid();
        }

        private void updateUrunlerInDataGrid()
        {
            urunler = depo.Rapor();
            urunlerDataGrid.DataSource = null;
            urunlerDataGrid.DataSource = urunler;
            if (urunlerDataGrid.Rows.Count > 0 )
            {
                silBtn.Enabled = true;
                guncelleBtn.Enabled = true;
            } else
            {
                silBtn.Enabled = false;
                guncelleBtn.Enabled = false;
            }
        }

        private void ekleBtn_Click(object sender, EventArgs e)
        {
            string ad = adText.Text;
            int stok = Convert.ToInt32(stokText.Text);  
            double fiyat = Convert.ToDouble(fiyatText.Text);
            int ut = Convert.ToInt32(utText.Text);
            int skt = Convert.ToInt32(sktText.Text);
            Urun yeniUrun = new Urun(ad, stok, fiyat, ut, skt);
            depo.Ekle(yeniUrun);
            updateUrunlerInDataGrid();
            adText.Text = "";
            stokText.Text = "";
            fiyatText.Text = "";
            utText.Text = "";
            sktText.Text = "";
        }

        private void silBtn_Click(object sender, EventArgs e)
        {
            var secilenSatirler = urunlerDataGrid.SelectedRows;
            if (secilenSatirler.Count > 0)
            {
                Urun secilenUrun = (Urun) secilenSatirler[0].DataBoundItem;
                depo.Sil(secilenUrun);
                updateUrunlerInDataGrid();
            }
        }

        private void guncelleBtn_Click(object sender, EventArgs e)
        {
            var secilenSatirler = urunlerDataGrid.SelectedRows;
            if (secilenSatirler.Count > 0)
            {
                Urun secilenUrun = (Urun)secilenSatirler[0].DataBoundItem;
                new UrunGuncellemeForm(secilenUrun, depo).ShowDialog();
                updateUrunlerInDataGrid();
            }
        }
    }
}
