﻿namespace RestorantOdevi
{
    partial class SiparisVerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.yemekListBox = new System.Windows.Forms.ListBox();
            this.silBtn = new System.Windows.Forms.Button();
            this.ekleBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.yemekCombo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.kaydetBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // yemekListBox
            // 
            this.yemekListBox.FormattingEnabled = true;
            this.yemekListBox.Location = new System.Drawing.Point(251, 93);
            this.yemekListBox.Name = "yemekListBox";
            this.yemekListBox.Size = new System.Drawing.Size(318, 316);
            this.yemekListBox.TabIndex = 50;
            // 
            // silBtn
            // 
            this.silBtn.Location = new System.Drawing.Point(494, 64);
            this.silBtn.Name = "silBtn";
            this.silBtn.Size = new System.Drawing.Size(75, 23);
            this.silBtn.TabIndex = 49;
            this.silBtn.Text = "Sil";
            this.silBtn.UseVisualStyleBackColor = true;
            this.silBtn.Click += new System.EventHandler(this.silBtn_Click);
            // 
            // ekleBtn
            // 
            this.ekleBtn.Location = new System.Drawing.Point(16, 134);
            this.ekleBtn.Name = "ekleBtn";
            this.ekleBtn.Size = new System.Drawing.Size(75, 23);
            this.ekleBtn.TabIndex = 48;
            this.ekleBtn.Text = "Ekle";
            this.ekleBtn.UseVisualStyleBackColor = true;
            this.ekleBtn.Click += new System.EventHandler(this.ekleBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(249, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 20);
            this.label4.TabIndex = 47;
            this.label4.Text = "Verdiginiz Siparis";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 46;
            this.label2.Text = "Yemek Cesidi:";
            // 
            // yemekCombo
            // 
            this.yemekCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.yemekCombo.FormattingEnabled = true;
            this.yemekCombo.Location = new System.Drawing.Point(16, 93);
            this.yemekCombo.Name = "yemekCombo";
            this.yemekCombo.Size = new System.Drawing.Size(158, 21);
            this.yemekCombo.TabIndex = 45;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 24);
            this.label1.TabIndex = 44;
            this.label1.Text = "SIPARIS VER";
            // 
            // kaydetBtn
            // 
            this.kaydetBtn.Location = new System.Drawing.Point(690, 370);
            this.kaydetBtn.Name = "kaydetBtn";
            this.kaydetBtn.Size = new System.Drawing.Size(98, 68);
            this.kaydetBtn.TabIndex = 51;
            this.kaydetBtn.Text = "DEGISIKLERI KAYDET";
            this.kaydetBtn.UseVisualStyleBackColor = true;
            // 
            // SiparisVerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.kaydetBtn);
            this.Controls.Add(this.yemekListBox);
            this.Controls.Add(this.silBtn);
            this.Controls.Add(this.ekleBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.yemekCombo);
            this.Controls.Add(this.label1);
            this.Name = "SiparisVerForm";
            this.Text = "Siparis Ver";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox yemekListBox;
        private System.Windows.Forms.Button silBtn;
        private System.Windows.Forms.Button ekleBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox yemekCombo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button kaydetBtn;
    }
}