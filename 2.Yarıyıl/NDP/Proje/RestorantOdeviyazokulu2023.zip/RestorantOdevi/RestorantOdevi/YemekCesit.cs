﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    public class YemekCesit
    {
        public Yiyecek yiyecek;
        public Dictionary<Urun, int> malzeme;
        private Depo depo = new Depo();

        public string YiyecekAdi { get { return this.yiyecek.Adi; } }

        public YemekCesit(Yiyecek yiyecek, Dictionary<Urun, int> malzeme)
        {
            this.yiyecek = yiyecek;
            this.malzeme = malzeme;
        }

        public YemekCesit(string yiyecekSatir, string malzemeSatir)
        {
            string[] yiyecekArr = yiyecekSatir.Split(';');
            string yAd = yiyecekArr[0];
            string yCins = yiyecekArr[1];
            double yFiyat = Convert.ToDouble(yiyecekArr[2]);
            double yKdv = Convert.ToDouble(yiyecekArr[3]);
            Yiyecek yiyecek = new Yiyecek(yAd, yCins, yFiyat, yKdv);
            this.yiyecek = yiyecek;

            Dictionary<Urun, int> malzemeListesi = new Dictionary<Urun, int>();
            string[] malzemeArr = malzemeSatir.Split(';');
            foreach(string str in malzemeArr)
            {
                string[] arr = str.Split(':');
                Urun u = depo.GetUrun(arr[0]);
                int adet = Convert.ToInt32(arr[1]);
                malzemeListesi.Add(u, adet);
            }
            this.malzeme = malzemeListesi;
        }

        public string malzemeSatir()
        {
            string str = "";
            foreach(KeyValuePair<Urun, int> kvp in malzeme)
            {
                str += $"{kvp.Key.Adi}:{kvp.Value};";
            }
            return str.Substring(0,str.Length-1);
        }

        public string yiyecekSatir()
        {
            return $"{this.yiyecek.Yazdir()}";
        }
    }
}
