﻿namespace RestorantOdevi
{
    partial class YemekCesitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cesitListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.malzemeListBox = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cesitAdText = new System.Windows.Forms.TextBox();
            this.ekleCesitBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.silCesitBtn = new System.Windows.Forms.Button();
            this.guncelleCesitBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.malzemeSil = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.urunlerCombo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.malzemeAdetText = new System.Windows.Forms.TextBox();
            this.malzemeEkle = new System.Windows.Forms.Button();
            this.kaydetBtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cesitCinsText = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cesitFiyatText = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cesitKdvText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cesitListBox
            // 
            this.cesitListBox.FormattingEnabled = true;
            this.cesitListBox.Location = new System.Drawing.Point(12, 191);
            this.cesitListBox.Name = "cesitListBox";
            this.cesitListBox.Size = new System.Drawing.Size(156, 238);
            this.cesitListBox.TabIndex = 0;
            this.cesitListBox.SelectedValueChanged += new System.EventHandler(this.cesitListBox_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "YEMEK CESITLERI";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Mecvut Cesitler:";
            // 
            // malzemeListBox
            // 
            this.malzemeListBox.FormattingEnabled = true;
            this.malzemeListBox.Location = new System.Drawing.Point(282, 191);
            this.malzemeListBox.Name = "malzemeListBox";
            this.malzemeListBox.Size = new System.Drawing.Size(156, 238);
            this.malzemeListBox.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(200, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "isim:";
            // 
            // cesitAdText
            // 
            this.cesitAdText.Location = new System.Drawing.Point(246, 52);
            this.cesitAdText.Name = "cesitAdText";
            this.cesitAdText.ShortcutsEnabled = false;
            this.cesitAdText.Size = new System.Drawing.Size(131, 20);
            this.cesitAdText.TabIndex = 8;
            // 
            // ekleCesitBtn
            // 
            this.ekleCesitBtn.Location = new System.Drawing.Point(690, 54);
            this.ekleCesitBtn.Name = "ekleCesitBtn";
            this.ekleCesitBtn.Size = new System.Drawing.Size(75, 23);
            this.ekleCesitBtn.TabIndex = 10;
            this.ekleCesitBtn.Text = "Ekle";
            this.ekleCesitBtn.UseVisualStyleBackColor = true;
            this.ekleCesitBtn.Click += new System.EventHandler(this.ekleCesitBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Yeni Yemek Cesidi Ekle:";
            // 
            // silCesitBtn
            // 
            this.silCesitBtn.Location = new System.Drawing.Point(93, 162);
            this.silCesitBtn.Name = "silCesitBtn";
            this.silCesitBtn.Size = new System.Drawing.Size(75, 23);
            this.silCesitBtn.TabIndex = 11;
            this.silCesitBtn.Text = "Sil";
            this.silCesitBtn.UseVisualStyleBackColor = true;
            this.silCesitBtn.Click += new System.EventHandler(this.silCesitBtn_Click);
            // 
            // guncelleCesitBtn
            // 
            this.guncelleCesitBtn.Location = new System.Drawing.Point(12, 162);
            this.guncelleCesitBtn.Name = "guncelleCesitBtn";
            this.guncelleCesitBtn.Size = new System.Drawing.Size(75, 23);
            this.guncelleCesitBtn.TabIndex = 12;
            this.guncelleCesitBtn.Text = "Guncelle";
            this.guncelleCesitBtn.UseVisualStyleBackColor = true;
            this.guncelleCesitBtn.Click += new System.EventHandler(this.guncelleCesitBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(278, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Malzemeler:";
            // 
            // malzemeSil
            // 
            this.malzemeSil.Location = new System.Drawing.Point(363, 162);
            this.malzemeSil.Name = "malzemeSil";
            this.malzemeSil.Size = new System.Drawing.Size(75, 23);
            this.malzemeSil.TabIndex = 14;
            this.malzemeSil.Text = "Sil";
            this.malzemeSil.UseVisualStyleBackColor = true;
            this.malzemeSil.Click += new System.EventHandler(this.malzemeSil_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(444, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Malzeme Ekle:";
            // 
            // urunlerCombo
            // 
            this.urunlerCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.urunlerCombo.FormattingEnabled = true;
            this.urunlerCombo.Location = new System.Drawing.Point(448, 254);
            this.urunlerCombo.Name = "urunlerCombo";
            this.urunlerCombo.Size = new System.Drawing.Size(157, 21);
            this.urunlerCombo.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(444, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Mecvut Urunler:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(444, 290);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "Adet:";
            // 
            // malzemeAdetText
            // 
            this.malzemeAdetText.Location = new System.Drawing.Point(448, 314);
            this.malzemeAdetText.Name = "malzemeAdetText";
            this.malzemeAdetText.Size = new System.Drawing.Size(157, 20);
            this.malzemeAdetText.TabIndex = 20;
            // 
            // malzemeEkle
            // 
            this.malzemeEkle.Location = new System.Drawing.Point(448, 357);
            this.malzemeEkle.Name = "malzemeEkle";
            this.malzemeEkle.Size = new System.Drawing.Size(75, 23);
            this.malzemeEkle.TabIndex = 21;
            this.malzemeEkle.Text = "Ekle";
            this.malzemeEkle.UseVisualStyleBackColor = true;
            this.malzemeEkle.Click += new System.EventHandler(this.malzemeEkle_Click);
            // 
            // kaydetBtn
            // 
            this.kaydetBtn.Location = new System.Drawing.Point(690, 370);
            this.kaydetBtn.Name = "kaydetBtn";
            this.kaydetBtn.Size = new System.Drawing.Size(98, 68);
            this.kaydetBtn.TabIndex = 22;
            this.kaydetBtn.Text = "DEGISIKLERI KAYDET";
            this.kaydetBtn.UseVisualStyleBackColor = true;
            this.kaydetBtn.Click += new System.EventHandler(this.kaydetBtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(196, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Cins:";
            // 
            // cesitCinsText
            // 
            this.cesitCinsText.Location = new System.Drawing.Point(246, 78);
            this.cesitCinsText.Name = "cesitCinsText";
            this.cesitCinsText.ShortcutsEnabled = false;
            this.cesitCinsText.Size = new System.Drawing.Size(131, 20);
            this.cesitCinsText.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(458, 78);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 20);
            this.label10.TabIndex = 25;
            this.label10.Text = "Fiyat:";
            // 
            // cesitFiyatText
            // 
            this.cesitFiyatText.Location = new System.Drawing.Point(511, 78);
            this.cesitFiyatText.Name = "cesitFiyatText";
            this.cesitFiyatText.ShortcutsEnabled = false;
            this.cesitFiyatText.Size = new System.Drawing.Size(131, 20);
            this.cesitFiyatText.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(417, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 20);
            this.label11.TabIndex = 27;
            this.label11.Text = "KDV Orani:";
            // 
            // cesitKdvText
            // 
            this.cesitKdvText.Location = new System.Drawing.Point(511, 54);
            this.cesitKdvText.Name = "cesitKdvText";
            this.cesitKdvText.ShortcutsEnabled = false;
            this.cesitKdvText.Size = new System.Drawing.Size(131, 20);
            this.cesitKdvText.TabIndex = 28;
            // 
            // YemekCesitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cesitKdvText);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cesitFiyatText);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cesitCinsText);
            this.Controls.Add(this.kaydetBtn);
            this.Controls.Add(this.malzemeEkle);
            this.Controls.Add(this.malzemeAdetText);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.urunlerCombo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.malzemeSil);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.guncelleCesitBtn);
            this.Controls.Add(this.silCesitBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cesitAdText);
            this.Controls.Add(this.ekleCesitBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.malzemeListBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cesitListBox);
            this.Name = "YemekCesitForm";
            this.Text = "Yemek Cesitleri";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox cesitListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox malzemeListBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox cesitAdText;
        private System.Windows.Forms.Button ekleCesitBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button silCesitBtn;
        private System.Windows.Forms.Button guncelleCesitBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button malzemeSil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox urunlerCombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox malzemeAdetText;
        private System.Windows.Forms.Button malzemeEkle;
        private System.Windows.Forms.Button kaydetBtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox cesitCinsText;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox cesitFiyatText;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox cesitKdvText;
    }
}