﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    public class GunlukYemek
    {
        public YemekCesit yc { get; set; }
        public string kisilikKalanGoster { get { return $"{this.yc.YiyecekAdi} :: {this.Adet - this.satilan} kisilik"; } }
        public string Goster { get { return $"{this.yc.YiyecekAdi} :: {this.Adet} adet"; } }
        public int Adet { get; set; }
        public int satilan { get; set; } = 0;

        public GunlukYemek(YemekCesit yc, int adet)
        {
            this.yc = yc;
            this.Adet = adet;
        }
    }
}
