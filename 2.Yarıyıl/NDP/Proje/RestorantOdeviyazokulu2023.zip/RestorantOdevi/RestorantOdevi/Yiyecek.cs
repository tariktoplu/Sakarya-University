﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    public class Yiyecek
    {
        public string Adi { get; set; }
        public string Cins { get; set; }
        public double Fiyat { get; set; }
        public double KdvOrani { get; set; }
        
        public Yiyecek(string adi, string cins, double fiyat, double kdvOrani)
        {
            Adi = adi;
            Cins = cins;
            Fiyat = fiyat;
            KdvOrani = kdvOrani;
        }

        public virtual string Yazdir()
        {
            return $"{Adi};{Cins};{Fiyat};{KdvOrani}";
        }
    }
}
