﻿namespace RestorantOdevi
{
    partial class UrunGuncellemeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.sktText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.utText = new System.Windows.Forms.TextBox();
            this.stokText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.fiyatText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.adText = new System.Windows.Forms.TextBox();
            this.guncelleBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "son kullanma yili:";
            // 
            // sktText
            // 
            this.sktText.Location = new System.Drawing.Point(146, 162);
            this.sktText.Name = "sktText";
            this.sktText.Size = new System.Drawing.Size(131, 20);
            this.sktText.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(63, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "uretim yili:";
            // 
            // utText
            // 
            this.utText.Location = new System.Drawing.Point(146, 136);
            this.utText.Name = "utText";
            this.utText.Size = new System.Drawing.Size(131, 20);
            this.utText.TabIndex = 4;
            // 
            // stokText
            // 
            this.stokText.Location = new System.Drawing.Point(146, 84);
            this.stokText.Name = "stokText";
            this.stokText.Size = new System.Drawing.Size(131, 20);
            this.stokText.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(98, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "fiyat:";
            // 
            // fiyatText
            // 
            this.fiyatText.Location = new System.Drawing.Point(146, 110);
            this.fiyatText.Name = "fiyatText";
            this.fiyatText.Size = new System.Drawing.Size(131, 20);
            this.fiyatText.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(61, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "stok adet:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(100, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "isim:";
            // 
            // adText
            // 
            this.adText.Location = new System.Drawing.Point(146, 58);
            this.adText.Name = "adText";
            this.adText.ShortcutsEnabled = false;
            this.adText.Size = new System.Drawing.Size(131, 20);
            this.adText.TabIndex = 1;
            // 
            // guncelleBtn
            // 
            this.guncelleBtn.Location = new System.Drawing.Point(146, 208);
            this.guncelleBtn.Name = "guncelleBtn";
            this.guncelleBtn.Size = new System.Drawing.Size(131, 23);
            this.guncelleBtn.TabIndex = 6;
            this.guncelleBtn.Text = "Guncelle";
            this.guncelleBtn.UseVisualStyleBackColor = true;
            this.guncelleBtn.Click += new System.EventHandler(this.guncelleBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 24);
            this.label1.TabIndex = 18;
            this.label1.Text = "URUN GUNCELLE";
            // 
            // UrunGuncellemeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 249);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.sktText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.utText);
            this.Controls.Add(this.stokText);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.fiyatText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.adText);
            this.Controls.Add(this.guncelleBtn);
            this.Name = "UrunGuncellemeForm";
            this.Text = "Urun Guncelleme";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox sktText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox utText;
        private System.Windows.Forms.TextBox stokText;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox fiyatText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox adText;
        private System.Windows.Forms.Button guncelleBtn;
        private System.Windows.Forms.Label label1;
    }
}