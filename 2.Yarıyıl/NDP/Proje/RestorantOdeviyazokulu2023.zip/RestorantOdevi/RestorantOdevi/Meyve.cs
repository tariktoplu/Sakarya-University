﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestorantOdevi
{
    internal class Meyve : Yiyecek 
    {
        public double Kalori { get; set; }

        public Meyve(string adi, string cins, double fiyat, double kdvOrani, double kalori) : base(adi, cins, fiyat, kdvOrani)
        {
            Kalori = kalori;
        }

        public override string Yazdir()
        {
            return $"{Adi};{Cins};{Fiyat};{KdvOrani};{Kalori}";
        }
    }
}
