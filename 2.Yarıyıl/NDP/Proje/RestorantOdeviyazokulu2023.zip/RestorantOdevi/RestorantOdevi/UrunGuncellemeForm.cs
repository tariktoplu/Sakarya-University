﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestorantOdevi
{
    public partial class UrunGuncellemeForm : Form
    {
        private string guncellenecekUrunAdi;
        private Depo depo;
        public UrunGuncellemeForm(Urun u, Depo depo)
        {
            InitializeComponent();
            this.guncellenecekUrunAdi = u.Adi;
            this.depo = depo;
            adText.Text = u.Adi;
            stokText.Text = u.StokAdet.ToString();
            fiyatText.Text = u.Fiyat.ToString();
            utText.Text = u.UretimTarihi.ToString();
            sktText.Text = u.SonKullanmaTarihi.ToString();
        }

        private void guncelleBtn_Click(object sender, EventArgs e)
        {
            string ad = adText.Text;
            int stok = Convert.ToInt32(stokText.Text);
            double fiyat = Convert.ToDouble(fiyatText.Text);
            int ut = Convert.ToInt32(utText.Text);
            int skt = Convert.ToInt32(sktText.Text);
            Urun guncelUrun = new Urun(ad, stok, fiyat, ut, skt);
            depo.Guncelle(guncellenecekUrunAdi, guncelUrun);
            this.Close();
        }
    }
}
