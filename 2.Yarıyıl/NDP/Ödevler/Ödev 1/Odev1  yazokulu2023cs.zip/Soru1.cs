﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI :        1
**				ÖĞRENCİ ADI   :        ÖMER KILINÇOĞLU
**				ÖĞRENCİ NUMARASI:      G211210571
**              DERSİN ALINDIĞI GRUP:  N.D.P.
****************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOoru1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("dizinin boyutu giriniz:");
            int boyut = Convert.ToInt32(Console.ReadLine());

            while (boyut <= 0)
            {
                Console.Write("dizinin boyutu sifirdan buyuk olmasi gerekir. boyut giriniz:");
                boyut = Convert.ToInt32(Console.ReadLine());
            }

            int[] dizi = new int[boyut];

            Console.Write("sayilar:");
            string sayilarString = Console.ReadLine();
            string[] sayilarDizi = sayilarString.Split();
            for (int i = 0; i < boyut; i++)
            {
                dizi[i] = Convert.ToInt32(sayilarDizi[i]);
            }

            Console.Write("bir index girin:");
            int index1 = Convert.ToInt32(Console.ReadLine());
            while (index1 < 0 || index1 >= boyut)
            {
                Console.Write("girilen indeks degeri uygun degildir. tekrar deneyin:");
                index1 = Convert.ToInt32(Console.ReadLine());
            }

            Console.Write("ikinci bir index girin:");
            int index2 = Convert.ToInt32(Console.ReadLine());
            while (index2 < 0 || index2 >= boyut)
            {
                Console.Write("girilen indeks degeri uygun degildir. tekrar deneyin:");
                index2 = Convert.ToInt32(Console.ReadLine());
            }

            int oncekiToplam = 0;
            int aralikToplam = 0;
            int sonrakiToplam = 0;

            for (int i = 0; i < index1; i++) oncekiToplam += dizi[i];
            for (int i = index1; i <= index2; i++) aralikToplam += dizi[i];
            for (int i = index2 + 1; i < boyut; i++) sonrakiToplam += dizi[i];

            Console.WriteLine("inceki toplam: " + oncekiToplam);
            Console.WriteLine("indisler arasi toplam: " + aralikToplam);
            Console.WriteLine("sonraki toplam: " + sonrakiToplam);
        }
    }
}
