﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI :        1
**				ÖĞRENCİ ADI   :        ÖMER KILINÇOĞLU
**				ÖĞRENCİ NUMARASI:      G211210571
**              DERSİN ALINDIĞI GRUP:  N.D.P.
****************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Menu");
            Console.WriteLine("1- string bir degiskende, string degeri substring kullanmadan ara.");
            Console.WriteLine("2- string bir degiskende, string degeri substring kullanarak ara.");
            Console.WriteLine("3- alfabenin karakterlerini bir string de ara kac adet geciyor bul ve ciz.");
            Console.Write("Seciminiz: ");
            int secim = Convert.ToInt32(Console.ReadLine());
            while (secim < 1 || secim > 3)
            {
                Console.Write("yanlis secenek. [1 - 3] arasi bir sayi seciniz: ");
                secim = Convert.ToInt32(Console.ReadLine());
            }

            if (secim == 1)
            {
                Console.Write("aranilacak kelime:");
                string aranilacak = Console.ReadLine();
                Console.WriteLine("karakter dizini:");
                string karakterDizi = Console.ReadLine();
                Console.WriteLine("=================================");
                int kelimeUzunlugu = aranilacak.Length;
                int indis = 0;
                while (karakterDizi.IndexOf(aranilacak, indis) != -1)
                {
                    indis = karakterDizi.IndexOf(aranilacak, indis);
                    Console.WriteLine("kelime " + aranilacak + " indis: " + indis);
                    indis += kelimeUzunlugu;
                }
            }
            else if (secim == 2)
            {
                Console.Write("aranilacak kelime:");
                string aranilacak = Console.ReadLine();
                Console.Write("karakter dizini:");
                string karakterDizi = Console.ReadLine();
                Console.WriteLine("=================================");
                int kelimeUzunlugu = aranilacak.Length;
                for (int i = 0; i < karakterDizi.Length - kelimeUzunlugu + 1; i++)
                {
                    if (karakterDizi.Substring(i, kelimeUzunlugu) == aranilacak)
                    {
                        Console.WriteLine("kelime " + aranilacak + " indis: " + i);
                    }
                }
            }
            else
            {
                Console.Write("karakter dizini:");
                string karakterDizi = Console.ReadLine().ToUpper();
                Console.WriteLine("=================================");
                int[] sayilar = new int[29];
                string alfabe = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ";
                Dictionary<char, int> tablo = new Dictionary<char, int>();
                foreach (char c in karakterDizi)
                {
                    if (alfabe.Contains(c))
                    {
                        if (tablo.ContainsKey(c))
                        {
                            tablo[c] = tablo[c] + 1;
                        }
                        else
                        {
                            tablo[c] = 1;
                        }
                    }
                }

                Console.WriteLine("karakter sayisi   grafik gosterimi");
                Console.WriteLine("==================================");
                foreach (char c in alfabe)
                {
                    if (tablo.ContainsKey(c))
                    {
                        Console.Write(c + ", sayisi: " + tablo[c] + " ");
                        for (int i = 0; i < tablo[c]; i++) Console.Write("*");
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine(c + ", sayisi: 0");
                    }
                }
            }
        }
    }
}
