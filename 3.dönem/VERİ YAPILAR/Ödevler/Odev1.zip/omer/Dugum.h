#ifndef DUGUM_H
#define DUGUM_H

class Dugum
{
	public:
		int deger;
		Dugum* sonraki;
		Dugum* onceki;
		Dugum(int);
};

#endif
