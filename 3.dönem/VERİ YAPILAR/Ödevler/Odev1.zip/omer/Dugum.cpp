#include "Dugum.h"
#include <cstddef>

Dugum::Dugum(int deger) {
	this->deger = deger;
	this->sonraki = NULL;
	this->onceki = NULL;
}