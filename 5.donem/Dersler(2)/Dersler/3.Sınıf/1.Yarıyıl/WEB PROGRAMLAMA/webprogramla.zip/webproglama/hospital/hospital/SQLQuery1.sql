﻿INSERT INTO Departments (DeparmentId, Name) VALUES (NEWID(), 'Kadın Doğum ve Çocuk Hastalıkları');

