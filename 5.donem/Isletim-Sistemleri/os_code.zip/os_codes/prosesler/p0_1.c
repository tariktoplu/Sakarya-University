// Fork örneği
//#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>



int main(int argc, char** argv) {

  
 int pid,pid2;

 printf("pid = %d\n", getpid());
 printf("parent pid = %d\n", getppid()); 

 pid=fork();
 pid2=fork();
 
 printf("Merhaba, pid degeri:%d\n",pid);
 printf("Merhaba, pid :%d\n",getpid());
 printf("Merhaba, pid2 :%d\n",pid2);

 
 wait(NULL);  


   return 0;
  
}
