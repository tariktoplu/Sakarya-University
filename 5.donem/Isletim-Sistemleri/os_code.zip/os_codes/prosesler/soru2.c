// Fork örneği
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
int deger = 5;
int main()
{
  int pid=8;  int deger2 = 3;
  pid = fork();
  if(pid == 0) { 
    printf("pid= %d\n", pid);
    wait(NULL);
    printf("deger= %d\n", deger); 
    
  } else { // Burası ebeveyn
     printf("deger2= %d\n", deger2); 
sleep(2);
    
  } 
}
