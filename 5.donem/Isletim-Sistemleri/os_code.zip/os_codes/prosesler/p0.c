// Fork örneği
//#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>


int g=10;
int main(int argc, char** argv) {

  
 int return_degeri,a=9;

 printf("pid = %d\n", getpid());
 printf("parent pid = %d\n", getppid()); 

 
 return_degeri=fork();

 if(return_degeri>0) //ebeveyn
{
 
 printf("Merhaba burası ebeveyn\n");
 printf("pid = %d\n", getpid());
 printf("a = %d\n", a);
 printf("g = %d\n", g);
 printf("pid degisken = %d\n", return_degeri);
 a=1; g=2;
 printf("a = %d\n", a);
printf("g = %d\n", g);
}
 else if (return_degeri==0)//cocuk
{
printf("Merhaba burası çocuk proses\n");
printf("pid = %d\n", getpid());
printf("a = %d\n", a);
printf("g = %d\n", g);
printf("pid degisken = %d\n", return_degeri);
execlp("/usr/bin/xcalc", "xcalc", NULL);
}
else if(return_degeri<0)
printf("Proses olusmA hAtAsı");

 return 0;
  
}
