// Fork örneği
//#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(int argc, char** argv) {
  
 int donusdegeri;
 printf("pid = %d\n", getpid());
 printf("parent pid = %d\n", getppid()); 
 donusdegeri=fork();
 
 
	if(donusdegeri>0) //ebeveyn
{
 printf("Burası ebeveeyn proses\n");
 printf("pid = %d\n", donusdegeri);	
 printf("pid pArent = %d\n", getpid());
 printf("pid pparent = %d\n", getppid());
//pid2=fork();
} 
	else if(donusdegeri==0) //çocuk
{
printf("Burası child proses\n");
 printf("pid = %d\n", donusdegeri);	
 printf("pid child = %d\n", getpid());
 printf("pid parent = %d\n", getppid());
}



   return 0;
  
}
