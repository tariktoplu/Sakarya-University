/**
 * Figure 3.35
 */

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define SIZE 11

int nums[SIZE] = {0,1,2,3,4,5,6,7,8,9,10};

int main()
{
	int i; 	int pid;

    	pid = fork();

    	if (pid == 0) {
      		for (i = 0; i < SIZE; i++) {
        		nums[i] *= -i;
        		printf("CHILD: %d\n",nums[i]); /* LINE X */
			sleep(1);
      		} 
    	}
    	else if (pid > 0) { 
                
      		wait(NULL); //senkronizasyon
      		for (i = 0; i < SIZE; i++)
        	{	
			printf("PARENT: %d\n",nums[i]); /* LINE Y */
			sleep(1);

}
    	}

    	return 0;
  }
