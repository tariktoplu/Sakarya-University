// Fork örneği
//#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>



int main(int argc, char** argv) {

  
 int pid,pid2;
int sayi1,sayi2;

 printf("pid = %d\n", getpid());
 printf("parent pid = %d\n", getppid()); 
 printf("Merhaba\n");

 pid=fork();
 

 if(pid==0)
{
printf("Merhaba Burası Çocuk proses\n");
printf("Sayi1:");
scanf("%d",&sayi1);
printf("Sayi2:");
scanf("%d",&sayi2);
 printf("Sayi1 = %d\n", sayi1);
printf("Sayi2 = %d\n", sayi2);
printf("toplam = %d\n", sayi1+sayi2);
 printf("Cocuk pid2 = %d\n", getpid());
while(1);
}
else if(pid>0)
{
 printf("Merhaba burası ebeveynden c2 proses\n");
 printf("Ebeveyn C2 pid2 = %d\n", getpid());
 pid2=fork();
 if(pid2==0)
 {
 printf("xMerhaba Burası Çocuk2 proses\n");
printf("xSayi1:");
scanf("%d",&sayi1);
printf("xSayi2:");
scanf("%d",&sayi2);
 printf("xSayi1 = %d\n", sayi1);
printf("xSayi2 = %d\n", sayi2);
printf("xÇıkarma = %d\n", sayi1-sayi2);
 printf("xCocuk2 pid2 = %d\n", getpid());
while(1);
 }

while(1);
}
else
printf("Hata");


 return 0;
  
}
