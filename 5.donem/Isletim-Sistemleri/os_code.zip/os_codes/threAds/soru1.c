// Pthread örneği
#include<stdio.h>
#include<pthread.h>

#define N 10

char alfabe[26]; // Paylaşılan değişken
void task(int *a)
{
  int b = *a;
  alfabe[b]=(char)(65+b);
  pthread_exit(0);
}

int main()
{
  pthread_t tid[N]; //thread dizisi
  pthread_attr_t attr;
  int i;


  pthread_attr_init(&attr);
  
  for(i = 0; i < 26; i++) 
    {
   pthread_create(&(tid[i]), &attr, (void *) &task, &i);
   pthread_join(tid[i], NULL);
   printf("Sonuç = %s\n", alfabe);
    }

     

  pthread_exit(0);

  return 0;
}
