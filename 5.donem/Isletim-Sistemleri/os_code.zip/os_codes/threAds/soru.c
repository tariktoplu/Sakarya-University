// Pthread örneği
#include<stdio.h>
#include<pthread.h>

#define N 10

int sum=0; // Paylaşılan değişken
void task(int *a)
{
  int b = *a;
  int j;	
  printf("Merhaba burası thread %d\n", b/10);
  for(j=b;j<(b+10);j++)
  {
    sum+=j;
  }
  pthread_exit(0);
}

int main()
{
  pthread_t tid[N]; //thread dizisi
  pthread_attr_t attr;
  int i;


  pthread_attr_init(&attr);
  
  for(i = 0; i < 100; i+=10) 
    {
   pthread_create(&(tid[i]), &attr, (void *) &task, &i);
   pthread_join(tid[i], NULL);
   printf("Ara Sonuç = %d\n", sum);
    }

     

  printf("Sonuç = %d\n", sum);
  pthread_exit(0);

  return 0;
}
