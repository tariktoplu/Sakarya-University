#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>

int main() {
    pid_t pid = fork();
    if (pid == 0) {
        while (1) {
            sleep(1);
            printf("ping\n");
            raise(SIGSTOP);
        }
    }
    while (1) {
        // Wait for child to self-halt
        waitpid(-1, NULL, WUNTRACED);
        
        sleep(1);
        printf("pong\n");
        
        // Make the child continue its loop
        kill(pid, SIGCONT);
    }
    return 0;
}
