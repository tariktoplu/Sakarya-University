#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>
void foo()
{
  printf("CTRL-C ye basıldı\n");
  raise(SIGSTOP);
  //exit(1);
}
void foo2()
{
  printf("CTRL-Z ye basıldı\n");
   raise(SIGCONT);
  //exit(1);
}

int main() {

  signal(SIGINT, foo);//Interrupt from keyboard
  signal(SIGTSTP, foo2);


    pid_t pid = fork();
    if (pid == 0) {
        printf("Child: İş yapıyor...\n");
        sleep(1);

        printf("Child: Kendini durdurmak üzere...\n");
        raise(SIGSTOP);

        printf("Child: Yeniden uyAndı! İş yapıyor...\n");
        sleep(2);

        printf("Child: goodbye!\n");
        //exit(0); 
	// :)
    }
    
    printf("Parent: İş yapıyor...\n");
    sleep(2);

    printf("Parent: Çocuğun kendi kendine durmasını bekliyor...\n");
    waitpid(pid, NULL, WUNTRACED);
    printf("Parent: child duraklatıldı! senk noktasına ulaşıldı. DevAm etmek üzere\n\n");
    kill(pid, SIGCONT);
    
    
    printf("Parent:  SIGCONT sinyali gönderildi, parent iş yapıyor...\n");
    sleep(1);
    
    printf("Parent: çocuğun çıkmAsını bekliyor...");
    waitpid(pid, NULL, 0);
    printf("Parent: Çocuk çıktı\n");
    return 0;
}
