#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
pid_t pid;
void foo()
{
  printf("CTRL-C ye basıldı\n");
  //raise(SIGCONT);
kill(pid, SIGCONT);
  //exit(1);
}
void foo2()
{
  printf("CTRL-Z ye basıldı\n");
   waitpid(-1, NULL, WUNTRACED);
  //exit(1);
}
void foo3()
{
  printf("CTRL-/ ye basıldı\n");
   
  exit(1);
}

int main() {
    signal(SIGINT, foo);//Interrupt from keyboard
    signal(SIGTSTP, foo2);
    signal(SIGQUIT, foo3);
    pid = fork();
    if (pid == 0) {
        while (1) {
            sleep(1);
            //printf("ping\n");
             printf("A\n");
            raise(SIGSTOP);
        }
    }
    while (1) {
        // Wait for child to self-halt
        waitpid(-1, NULL, WUNTRACED);
        
        sleep(1);
        //printf("pong\n");
printf("B\n");
        
        // Make the child continue its loop
        kill(pid, SIGCONT);
    }
    return 0;
}

