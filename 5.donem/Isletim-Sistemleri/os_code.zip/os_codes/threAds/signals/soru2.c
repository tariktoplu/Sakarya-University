/*ipc_signal.c*/

#include<stdio.h>
#include<signal.h>


static int turn=0;

void p_pin(){
printf("function pin!\n");
if(turn==0)
{
  printf("pin!\n");
   sleep(1);
   turn=1;
  }
else
sleep(1);

raise(12);
 
}


void c_pon(){
  printf("function pon!\n");
  if(turn==1){
  printf("pon!\n");
  sleep(1);
  turn=0;
 }
 
}

int main(){

  
   pid_t pid;
  signal(12,p_pin);
pid = fork();
printf("pin & pon!\n");
 
if (pid==0){
   while(1){
printf("Child turn:%d\n",turn);
printf("child pid:%d\n",pid);
printf("child ppid:%d\n",getppid());
    //get parent's pid
     signal(10, c_pon);
     kill(getppid(), 12);
  sleep(1);
     
  }
  
  }
else if (pid>0)
{/*
    while(1){
printf("Parent turn:%d\n",turn);
printf("pArent pid:%d\n",pid);
printf("pArent ppid:%d\n",getpid());
    //just wait for child to terminate
   
   kill(pid,10);
   sleep(1);
  
   }
*/
 while(1){
}
wait(NULL);
  }


}

