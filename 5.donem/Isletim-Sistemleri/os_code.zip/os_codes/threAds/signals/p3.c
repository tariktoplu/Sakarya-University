// Signals
#include<stdio.h>
#include<stdlib.h>
#include<signal.h>

void foo()
{
  printf("CTRL-C ye basıldı\n");
  exit(1);
}
void foo2()
{
  printf("CTRL-Z ye basıldı\n");
 // exit(1);
}



int main()
{
  signal(SIGINT, foo);//Interrupt from keyboard
  signal(SIGTSTP, foo2);

  while(1);
}
