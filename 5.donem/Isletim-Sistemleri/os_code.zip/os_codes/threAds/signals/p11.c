#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>

int main() {

    int pid = fork();
    if (pid == 0) { //çocuk proses
        printf("Child: İş yapıyor...\n");
        sleep(1);

        printf("Child: Kendini durdurmak üzere...\n");
        raise(SIGSTOP);

        printf("Child: Yeniden uyAndı! İş yapıyor...\n");
        sleep(2);

        printf("Child: goodbye!\n");
        exit(0); 
	// :)
    }
else if (pid>0) {
    
    printf("Parent: İş yapıyor...\n");
    //sleep(2);
    
    printf("Parent: Çocuğun kendi kendine durmasını bekliyor...\n");
    waitpid(pid, NULL, WUNTRACED);
    printf("Parent: child duraklatıldı! senk noktasına ulaşıldı. Devam etmek üzere\n\n");
    sleep(1);
    kill(pid, SIGCONT); //çocuk proses devAm etsin
       
    printf("Parent:  SIGCONT sinyali gönderildi, parent iş yapıyor...\n");
    sleep(1);
    
    printf("Parent: çocuğun çıkmAsını bekliyor...");
    waitpid(pid, NULL, 0);//wait(NULL);
    printf("Parent: Çocuk çıktı\n");
    return 0;
}

}
