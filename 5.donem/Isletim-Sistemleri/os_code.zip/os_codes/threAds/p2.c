// Pthread örneği
#include<stdio.h>
#include<pthread.h>
#include<unistd.h> //implicit declaration of func of sleep

#define N 10

int s = 0; // Paylaşılan değişken

void task(int *a)
{
  int b =*a;
  s=s+b;
  //*a=*a+1;
  printf("Merhaba burası thread b = %d\n", b);
  printf("Merhaba burası thread global deg. = %d\n", s);
  //printf("Merhaba burası thread a. = %d\n", *a);

  pthread_exit(0);
}

int main()
{
  pthread_t tid[N]; //thread dizisi
  pthread_attr_t attr;
  int i;


  pthread_attr_init(&attr);
  
  for(i = 0; i < N; i++) 
    {
  pthread_create(&(tid[i]), NULL, (void *) &task, &i); 
  //pthread_join(tid[i], NULL); 
  //sleep(1);
 
}	
  //wait for the thread to exit
  for(i = 0; i < N; i++)  
  ;
   

  //pthread_exit(0);

  return 0;
}
