// Pipe örneği
#include<stdio.h> 
#include<stdlib.h> 
#include<fcntl.h> 
#include<unistd.h>

int main()
{
  int pid, ret;
  int pd[2];

  pipe(pd);
 
  pid = fork();
  if(pid > 0){ // Ebeveyn - yazan
    close(pd[0]); //okuma pasif
    write(pd[1], "MerhabaSakaryaUniversitesi",20);
    printf("-----Ebeveyn yazdı----- %d\n",ret); 
 
  } else if(pid == 0){ // Yavru okuyan
    
    char buf[20];
    close(pd[1]); //yazma pasif
    read(pd[0], buf, 20); //okuma aktif
    printf("-----Yavru okudu-----%d\n",ret); 
    printf("okunan = %s\n", buf);
  }


}
