#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *functionC();
void *functionD();
pthread_mutex_t kilit1 = PTHREAD_MUTEX_INITIALIZER;
int  counter = 5;

main()
{
   int rc1, rc2;
   pthread_t thread1, thread2;

   /* Create independent threads each of which will execute functionC */

   if( (rc1=pthread_create( &thread1, NULL, &functionC, NULL)) )
   {
      printf("Thread creation failed: %d\n", rc1);
   }


   if( (rc2=pthread_create( &thread2, NULL, &functionD, NULL)) )
   {
      printf("Thread creation failed: %d\n", rc2);
   }
   pthread_join( thread1, NULL); //threAd1'in bitmesini bekle
   pthread_join( thread2, NULL);  //threAd2'in bitmesini bekle
   
   exit(0);
}

void *functionC()  //atomik fonk.
{
 pthread_mutex_lock( &kilit1 );

counter++;

   printf("Counter value: %d\n",counter);
  pthread_mutex_unlock( &kilit1);
}
void *functionD() //atomik fonksiyon
{
   pthread_mutex_lock( &kilit1 );
int i=0;
for (i=0;i<100;i++) 
   counter--;
   printf("Counter value2: %d\n",counter);
  pthread_mutex_unlock( &kilit1 );
}
