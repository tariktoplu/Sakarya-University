﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3
{
    class CepTel : Urun // CepTel classı oluşturuldu ve Urunden kalıtım aldırıldı.
    {
        // kullanılacak ekstra değişkenler tanımlandı.
        public int DahiliHafıza;
        public int RamKapasitesi;
        public int PilGucu;

        public CepTel(string Ad, string Marka, string Model, string Ozellik, double HamFiyat, int SecilenAdet, int DahiliHafıza,int RamKapasitesi,int PilGucu)// CepTel classının kurucusu parametreli bir şekilde oluşturuldu.
        {
            this.Ad = Ad;
            this.Marka = Marka;
            this.Model = Model;
            this.Ozellik = Ozellik;
            this.HamFiyat = HamFiyat;
            this.SecilenAdet = SecilenAdet;
            this.DahiliHafıza = DahiliHafıza;
            this.RamKapasitesi = RamKapasitesi;
            this.PilGucu = PilGucu;
        }

        public override double KdvUygula()// KdvUygula fonksiyonu oluşturulup override yapıldı.
        {
            double fiyat = HamFiyat * 1.20 * SecilenAdet;
            return fiyat;
        }
       
    }

}
