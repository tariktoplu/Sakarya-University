﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3
{
    class Buzdolabı : Urun // Buzdolabı classı oluşturuldu ve Urunden kalıtım aldırıldı.
    {
        // kullanılacak ekstra değişkenler tanımlandı.
        public int icHacim;
        public string EnerjiSinifi;

        public Buzdolabı(string Ad, string Marka, string Model, string Ozellik, double HamFiyat, int SecilenAdet, int icHacim, string EnerjiSinifi) // Buzdolabı classının kurucusu parametreli bir şekilde oluşturuldu.
        {
            this.Ad = Ad;
            this.Marka = Marka;
            this.Model = Model;
            this.Ozellik = Ozellik;
            this.HamFiyat = HamFiyat;
            this.SecilenAdet = SecilenAdet;
            this.icHacim = icHacim;
            this.EnerjiSinifi = EnerjiSinifi;
        }

        public override double KdvUygula() // KdvUygula fonksiyonu oluşturulup override yapıldı.
        {
            double fiyat = HamFiyat * 1.05 * SecilenAdet;
            return fiyat;
        }

    }
}
