﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3
{
    class LedTv : Urun // Ledtv classı oluşturuldu ve Urunden kalıtım aldırıldı.
    {
        // kullanılacak ekstra değişkenler tanımlandı.
        public int EkranBoyutu;
        public int EkranCozunurlugu;

        public LedTv(string Ad, string Marka, string Model, string Ozellik, double HamFiyat, int SecilenAdet, int EkranBoyutu, int EkranCozunurlugu) // Ledtv classının kurucusu parametreli bir şekilde oluşturuldu.
        {
            this.Ad = Ad;
            this.Marka = Marka;
            this.Model = Model;
            this.Ozellik = Ozellik;
            this.HamFiyat = HamFiyat;
            this.SecilenAdet = SecilenAdet;
            this.EkranBoyutu = EkranBoyutu;
            this.EkranCozunurlugu = EkranCozunurlugu;

        }

        public override double KdvUygula() // KdvUygula fonksiyonu oluşturulup override yapıldı.
        {
            double fiyat = HamFiyat * 1.18 * SecilenAdet;
            return fiyat;
        }
    }
}
