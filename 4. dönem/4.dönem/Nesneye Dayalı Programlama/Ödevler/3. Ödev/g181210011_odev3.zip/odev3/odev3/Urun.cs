﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3
{
  public  abstract class Urun // Urun classı oluşturuldu.
    {
        // kullanılacak değişkenler tanımlandı.
        public string Ad;
        public string Marka;
        public string Model;
        public string Ozellik;
        public int StokAdedi;
        public double HamFiyat;
        public int SecilenAdet;

        static Random  RastgeleSayi = new Random(); //rastgele fonksiyon nesnesi oluşturuldu. Her üründe farklı sonuç çıkması için static olarak yazıldı.
        public Urun(string Ad="", string Marka="", string Model="", string Ozellik="", double HamFiyat=0, int SecilenAdet=0) //Urun classının kurucusu parametreli bir şekilde oluşturuldu.
        {
            
            this.Ad = Ad;
            this.Marka = Marka;
            this.Model = Model;
            this.Ozellik = Ozellik;
            this.HamFiyat = HamFiyat;
            this.SecilenAdet = SecilenAdet;
            StokAdedi = RastgeleSayi.Next(1, 100); // stokadedine rastgele sayılar atandı.
        }
        public abstract double KdvUygula(); // KdvUygula fonksiyonu oluşturuldu.Her urunun kendi kadevi fiyatı olacağından kendi classında verride yapılacak.
    }
}