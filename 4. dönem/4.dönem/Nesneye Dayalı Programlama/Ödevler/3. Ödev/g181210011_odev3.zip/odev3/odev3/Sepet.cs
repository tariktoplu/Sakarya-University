﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace odev3
{

    public class Sepet // Sepet classı oluşturuldu
    {
        private const int adet = 4; // 4 ürün bulunduğundan bu kadarlık bir sabit değişken tanımlandı.
        public Urun[] urunler = new Urun[adet]; // Urun classından urunler adında bir nesne oluşturuldu.
        private int counter = 0;
        public double Toplam_fiyat() // Bütün ürünlerin kdvli toplam fiyatları toplanan fonksiyon.
        {
            double toplam_fiyat = 0;
            foreach (var item in urunler)
            {
                toplam_fiyat += item.KdvUygula();
            }
            return toplam_fiyat;
        }
       

        public void SepeteUrunEkle(Urun urun) // Parametresi Urun tipinde olacak olan SepeteUrunEkle metodu yazıldı.
        {
            if (counter < adet)
            {
                urunler[counter] = urun;
                counter++;
            }
        }
    }

}
