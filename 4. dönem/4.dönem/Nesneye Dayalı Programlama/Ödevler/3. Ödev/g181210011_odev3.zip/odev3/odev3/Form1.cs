﻿/****************************************************************************
**					    SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				     BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				    NESNEYE DAYALI PROGRAMLAMA DERSİ
**					     2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: 3
**				ÖĞRENCİ ADI............: Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI.......: G181210011
**              DERSİN ALINDIĞI GRUP...: 2. Öğretim C Grubu
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace odev3
{

    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public Sepet sepet;// global sepet nesnesi tanımlandı.
        LedTv led; // global led nesnesi tanımlandı.
        Buzdolabı buz;// global buz nesnesi tanımlandı.
        Laptop laptop;// global laptop nesnesi tanımlandı.
        CepTel cep;// global cep nesnesi tanımlandı.
       

        private void Form1_Load(object sender, EventArgs e)
        {
            sepet = new Sepet();// sepet nesnesi oluşturuldu.
            led = new LedTv("Led Tv", "Samsung", "Smart TV", "4K", 4000, 1, 140, 1080); // led nesnesi oluşturuldu.
            label2.Text = Convert.ToString(led.HamFiyat); //label2ye hamfiyat yazıldı.
            label4.Text = Convert.ToString(led.StokAdedi); // label4e stokadedi yazıldı.


            buz = new Buzdolabı("Buzdolabı", "Arcelik", "NoFrost", "4kapak", 3500, 1, 5, "A++");// buz nesnesi oluşturuldu.
            label9.Text = Convert.ToString(buz.HamFiyat);//label9a hamfiyat yazıldı.
            label7.Text = Convert.ToString(buz.StokAdedi);// label7ye stokadedi yazıldı.

            laptop = new Laptop("Laptop", "Monster", "Abra A15", "4K", 6000, 1, 16, 1080, 3300, 16, 4500);// laptop nesnesi oluşturuldu.
            label14.Text = Convert.ToString(laptop.HamFiyat);//label14e hamfiyat yazıldı.
            label12.Text = Convert.ToString(laptop.StokAdedi);// label12ye stokadedi yazıldı.

            cep = new CepTel("Cep Telefonu", "Samsung", "g", "4K", 2500, 1, 64, 4, 3000);// cep nesnesi oluşturuldu.
            label19.Text = Convert.ToString(cep.HamFiyat);//label19a hamfiyat yazıldı.
            label17.Text = Convert.ToString(cep.StokAdedi);// labe17ye stokadedi yazıldı.

        }

        private void button1_Click(object sender, EventArgs e)
        {
            led.SecilenAdet = Convert.ToInt32(numericUpDown1.Value); //ledin SecilenAdedine numericUpDown1 in valuesi yazıldı.
            buz.SecilenAdet = Convert.ToInt32(numericUpDown2.Value); //buzun SecilenAdedine numericUpDown1 in valuesi yazıldı.
            laptop.SecilenAdet = Convert.ToInt32(numericUpDown3.Value); //laptopun SecilenAdedine numericUpDown1 in valuesi yazıldı.
            cep.SecilenAdet = Convert.ToInt32(numericUpDown4.Value); //cebin SecilenAdedine numericUpDown1 in valuesi yazıldı.

            if (listBox1.Items.Count > 0 && listBox2.Items.Count > 0 && listBox3.Items.Count > 0) //listboxlar doluysa button1 işlenmeyecek ve mesaj ekrana cıkacak.
            {
                button1.Enabled = false;
                MessageBox.Show("Sepet dolu...Lütfen sepeti temizleyin");
            }
            else
            {

                sepet.SepeteUrunEkle(led); //SepeteUrunEkle metodu led e göre çağrıldı.
                sepet.SepeteUrunEkle(buz); //SepeteUrunEkle metodu buz a göre çağrıldı.
                sepet.SepeteUrunEkle(laptop); //SepeteUrunEkle metodu laptop a göre çağrıldı.
                sepet.SepeteUrunEkle(cep);//SepeteUrunEkle metodu cep e göre çağrıldı.

                foreach (var item in sepet.urunler) //listboxlara ekleme işlemleri döngüyle yaptırıldı.
                {
                    if (item.SecilenAdet > item.StokAdedi) // eğer seçilen adet stok adedınden fazla ıse ekrana bunun mesajı cıkarıldı.
                    {
                        label25.Text = "0";
                        MessageBox.Show("Seçilen adet kadar ürün bulunmamaktadır...Lütfen sepeti temizleyin");
                        
                    }
                    else // değilse ekleme işlemleri yapıldı.
                    {
                        if (item.SecilenAdet > 0)
                        {
                            
                            listBox1.Items.Add(item.SecilenAdet); // listbox1 e secilen adet eklendi.
                            listBox2.Items.Add(item.Ad); // listbox2 ye ad eklendi.
                            listBox3.Items.Add(item.KdvUygula()); // listbox3 e kdvli fiyat klendi.

                            Stok_Eksilt(item, item.SecilenAdet);// Stok_Eksilt fonksiyonu çağrıldı.
                        }
                    }

                }
                label25.Text = sepet.Toplam_fiyat().ToString() + " ₺"; //label25 e toplam fiyat yazdırıldı.

                Stok_Update(); // Stok_Uptade fonksiyonu çağrıldı.
            }


        }
        void Stok_Update()
        {

            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;
            numericUpDown4.Value = 0;
            //led
            label4.Text = led.StokAdedi.ToString();
            //buz
            label7.Text = buz.StokAdedi.ToString();
            //lapyop
            label12.Text = laptop.StokAdedi.ToString();
            //ceptel
            label17.Text = cep.StokAdedi.ToString();

        }
        void Stok_Eksilt(Urun urun, int adet) //secilen adet kadar stoktan düşen fonksiyon.
        {
            switch (urun.Ad)
            {
                case "Led Tv":
                    led.StokAdedi -= adet;
                    break;
                case "Buzdolabı":
                    buz.StokAdedi -= adet;
                    break;
                case "Laptop":
                    laptop.StokAdedi -= adet;
                    break;
                case "Cep Telefonu":
                    cep.StokAdedi -= adet;
                    break;
                default:
                    break;
            }

        }
        void Stok_Arttir(string urun, int adet)//sepet temizlenince secilen ürünleri geri getiren fonksiyon.
        {
            switch (urun)
            {
                case "Led Tv":
                    led.StokAdedi += adet;
                    break;
                case "Buzdolabı":
                    buz.StokAdedi += adet;
                    break;
                case "Laptop":
                    laptop.StokAdedi += adet;
                    break;
                case "Cep Telefonu":
                    cep.StokAdedi += adet;
                    break;
                default:
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            foreach (var item in sepet.urunler) // sepeti temizle butonuna basılınca tekrardan stoklar esi haline getirildi.
            {
                Stok_Arttir(item.Ad, item.SecilenAdet);
            }

            Stok_Update();
            listBox1.Items.Clear();//listbox1 temizlendi.
            listBox2.Items.Clear();//listbox2 temizlendi.
            listBox3.Items.Clear();//listbox3 temizlendi.
            label25.Text = "0";// label25 sıfırlandı.
            button1.Enabled = true;// buton tekrardan çalışır hale geldi.
        }
    }
}
