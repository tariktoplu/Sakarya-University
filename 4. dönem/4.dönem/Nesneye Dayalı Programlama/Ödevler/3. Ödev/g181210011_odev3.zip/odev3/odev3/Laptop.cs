﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3
{
    class Laptop : Urun // Laptop classı oluşturuldu ve Urunden kalıtım aldırıldı.
    {
        // kullanılacak ekstra değişkenler tanımlandı.
        public int EkranBoyutu;
        public int EkranCozunurlugu;
        public int DahiliHafıza;
        public int RamKapasitesi;
        public int PilGucu;

        public Laptop(string Ad, string Marka, string Model, string Ozellik, double HamFiyat, int SecilenAdet, int EkranBoyutu, int EkranCozunurlugu, int DahiliHafıza, int RamKapasitesi, int PilGucu)// Laptop classının kurucusu parametreli bir şekilde oluşturuldu.
        {
            this.Ad = Ad;
            this.Marka = Marka;
            this.Model = Model;
            this.Ozellik = Ozellik;
            this.HamFiyat = HamFiyat;
            this.SecilenAdet = SecilenAdet;
            this.EkranBoyutu = EkranBoyutu;
            this.EkranCozunurlugu = EkranCozunurlugu;
            this.DahiliHafıza = DahiliHafıza;
            this.RamKapasitesi = RamKapasitesi;
            this.PilGucu = PilGucu;
        }

        public override double KdvUygula()// KdvUygula fonksiyonu oluşturulup override yapıldı.
        {
            double fiyat = HamFiyat * 1.15 * SecilenAdet;
            return fiyat;
        }
        
    }
}
