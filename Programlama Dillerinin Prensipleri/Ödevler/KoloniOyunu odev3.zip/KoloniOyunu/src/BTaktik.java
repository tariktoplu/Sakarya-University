import java.util.Random;
public class BTaktik extends Taktik {
	@Override
	public int savas() {
		Random rnd = new Random();
		return rnd.nextInt() % 1001;
	}
}
