
public abstract class Uretim {
	public abstract int uret();
}
