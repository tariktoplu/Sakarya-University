import java.util.Random;
import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.IconifyAction;
public class Oyun {
	private Koloni[] koloniler;
	private char[] kullanilanSemboller;
	private int i = 0;
	private int turSayisi = 0;
	Oyun() {
		System.out.print("Koloni Populasyonlari Gir (or: 15 17 234 23):");
		Scanner scn = new Scanner(System.in);
		String kullaniciGirisi = scn.nextLine();
		String[] koloniPopulasyonlarStr = kullaniciGirisi.split(" ");
		int koloniSayisi = koloniPopulasyonlarStr.length;
		koloniler = new Koloni[koloniSayisi];
		kullanilanSemboller = new char[koloniSayisi];
		for (String k: koloniPopulasyonlarStr) {
			int populasyon = Integer.parseInt(k);
			char sembol = sembolUret();
			Taktik taktik = taktikOlustur();
			Uretim uretim = uretimOlustur();
			Koloni koloni = new Koloni(sembol, populasyon, taktik, uretim);
			koloniler[this.i] = koloni;
			kullanilanSemboller[this.i] = sembol;
			this.i++;
		}
		
		while (!oyunBittiMi()) {
			tabloOlustur();
			turSavasi();
		}
		tabloOlustur();
	}
	
	private void tabloOlustur() {
		System.out.println("------------------------------------------------------");
		System.out.println("Tur Sayisi: " + this.turSayisi);
		System.out.println("Koloni   Populasyon   Yemek Stogu   Kazanma   Kaybetme");
		for (Koloni koloni: this.koloniler) {
			String satir = "";
			satir += String.format("%-6s", koloni.sembol) + "   ";
			satir += String.format("%-10s", koloni.yasiyorMu?koloni.populasyon:"--") + "   ";
			satir += String.format("%-10s", koloni.yasiyorMu?koloni.yemekStogu:"--") + "   ";
			satir += String.format("%-7s", koloni.yasiyorMu?koloni.kazanma:"--") + "   ";
			satir += String.format("%-8s", koloni.yasiyorMu?koloni.kaybetme:"--");
			System.out.println(satir);
		}
		System.out.println("------------------------------------------------------");
	}
	
	private char sembolUret() {
		char sembol;
		Random rnd = new Random();
		int sembolKod = rnd.nextInt(0x26FF - 0x25A0 + 1) + 0x25A0;
		sembol = (char) sembolKod;
		while (sembolKullanildiMi(sembol)) {
			sembolKod = rnd.nextInt(0x26FF - 0x25A0 + 1) + 0x25A0;
			sembol = (char) sembolKod;		
		}
		return sembol;
	}
	
	private boolean sembolKullanildiMi(char sembol) {
		for (char s: this.kullanilanSemboller) {
			if (s == sembol) return true;
		}
		return false;
	}
	
	private Taktik taktikOlustur() {
		Taktik taktik;
		Random rnd = new Random();
		if (rnd.nextInt() % 2 == 0) taktik = new ATaktik();
		else taktik = new BTaktik();
		return taktik;
	}
	
	private Uretim uretimOlustur() {
		Uretim uretim;
		Random rnd = new Random();
		if (rnd.nextInt() % 2 == 0) uretim = new AUretim();
		else uretim = new BUretim();
		return uretim;
	}
	
	private void savas(Koloni a, Koloni b) {
		int aSavasDegeri = a.savasTaktigi.savas();
		int bSavasDegeri = b.savasTaktigi.savas();
		
		Koloni kazandi, kaybetti;
		if (aSavasDegeri > bSavasDegeri) {
			kazandi = a;
			kaybetti = b;
		} else if (bSavasDegeri > aSavasDegeri) {
			kazandi = b;
			kaybetti = a;
		} else {
			if (a.populasyon > b.populasyon) {
				kazandi = a;
				kaybetti = b;
			} else if (b.populasyon > a.populasyon){
				kazandi = b;
				kaybetti = a;
			} else {
				kazandi = a;
				kaybetti = b;
				if (new Random().nextInt()%2 == 1) {
					kazandi = b;
					kaybetti = a;
				}
			}
		}
		
		int kazanmaFarki = Math.abs(bSavasDegeri - aSavasDegeri);
		double kazanmaFarkiOrani = kazanmaFarki*100/1000.0;
		
		kaybetti.populasyon = (int) (kaybetti.populasyon * (1 - kazanmaFarkiOrani/100));
		int verilecekYemekStogu = (int) (kaybetti.yemekStogu * kazanmaFarkiOrani / 100);
		kaybetti.yemekStogu -= verilecekYemekStogu;
		kazandi.yemekStogu += verilecekYemekStogu;
		kaybetti.kaybetme += 1;
		kazandi.kazanma += 1;
	}
	
	private void turSavasi() {
		this.turSayisi++;
		for (int i = 0; i < this.koloniler.length; i++) {
			if (!this.koloniler[i].yasiyorMu) continue;
			for (int j = i+1; j < this.koloniler.length; j++) {
				if (!this.koloniler[j].yasiyorMu) continue;
				savas(this.koloniler[i], this.koloniler[j]);
			}
		}
		for (Koloni k: this.koloniler) k.guncelle();
	}
	
	private boolean oyunBittiMi() {
		int yasiyorSayisi = 0;
		for (Koloni k : this.koloniler) {
			if (k.yasiyorMu) yasiyorSayisi++;
		}
		if (yasiyorSayisi <= 1) return true;
		else return false;
	}
}
