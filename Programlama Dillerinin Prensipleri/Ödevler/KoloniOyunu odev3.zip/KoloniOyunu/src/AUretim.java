import java.util.Random;
public class AUretim extends Uretim {
	@Override
	public int uret() {
		Random rnd = new Random();
		return (rnd.nextInt() % 10) + 1;
	}
}
