
public abstract class Taktik {
	public abstract int savas();
}
