
public class Koloni {
	char sembol;
	int populasyon;
	Taktik savasTaktigi;
	Uretim uretim;
	int yemekStogu;
	int kazanma;
	int kaybetme;
	boolean yasiyorMu = true;
	
	Koloni(char sembol, int populasyon, Taktik savasTaktigi, Uretim uretim) {
		this.sembol = sembol;
		this.populasyon = populasyon;
		this.savasTaktigi = savasTaktigi;
		this.uretim = uretim;
		this.yemekStogu = populasyon * populasyon;
		this.kaybetme = 0;
		this.kazanma = 0;
	}
	
	public void guncelle() {
		if (this.populasyon <=0 || this.yemekStogu <= 0) {
			this.yasiyorMu = false;
			return;
		}
		this.populasyon += (int) (this.populasyon * 0.2);
		this.yemekStogu -= 2*this.populasyon;
		this.yemekStogu += this.uretim.uret();
	}
}
