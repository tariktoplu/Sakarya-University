import java.util.Random;
public class BUretim extends Uretim {
	@Override
	public int uret() {
		Random rnd = new Random();
		return rnd.nextInt(10) + 1;
	}
}
